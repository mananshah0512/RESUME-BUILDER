const express = require("express");
const {join} = require("path");
const app = express();

app.set('views', join(__dirname, 'views'));
app.set('view engine', 'jade');

app.get("/resume", (req, res) => {
  const path1 = join(__dirname,"/index.html");
  res.sendFile(path1);
})

app.listen(3000,() => {
  console.log("The port is listening on 3000");
})